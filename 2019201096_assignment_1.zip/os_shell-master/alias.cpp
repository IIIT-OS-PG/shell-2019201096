#include<bits/stdc++.h>
#include<unistd.h>
#include<sys/wait.h>
#include<fcntl.h>
#include<map>
#include<string>
#include<algorithm>
using namespace std;

map<string,string>ump;
map<string,string>::iterator itr;
void makeshell(); 
char* rd_line();
char **tokenize(char *);
int executecmd(char **);
void pipeline(char ***,int);
void redirf(char ***,int,int);
void redapf(char ***,int,int);
int main(int argc,char** argv)
{
	makeshell();
	return 0;
}

void makeshell()
{ 
	int status;
	int uid;
	char *line;
	char **args;
	while(status){
	uid=getuid();
	if(uid==0)
		printf("#");
	else
		printf("$");
    line=rd_line();
    cout<<endl;
    args=tokenize(line);
    //cout<<args[0]<<endl;
    status=executecmd(args);
    free(line);
    free(args);
	}

}

#define size 1024
char* rd_line(){
	int buf=size;
	char *linebuf=(char*)malloc(sizeof(char) * buf);
	if(!linebuf){
				fprintf(stderr,"Memory allocation error\n");
				exit(EXIT_FAILURE);
	            }
    int i=0;
    int c;
	while(1){
    c =getchar();
    if(c==EOF || c=='\n'){
       linebuf[i]='\0';
       return linebuf;
    }
    else{
        linebuf[i]=c;
    }
    i++;
    if(i>=size)
    {
    buf=buf+size;
    linebuf=(char*)realloc(linebuf,sizeof(char)*buf);
    
    }

	}


}

#define count 256
char ** tokenize(char * line){
    int buf=count;
    char ** tokens=(char **)malloc(sizeof(char *)*buf);
    if(!tokens)
    {
        fprintf(stderr,"Memory allocation error\n");
                exit(EXIT_FAILURE);
    }
    char *token;
    int i;
    token=strtok(line," \t\n");
    while(token!=NULL)
    {
        tokens[i]=token;
        i++;
        token=strtok(NULL," \t\n");
        if(i>=count)
        {
            buf=buf+count;
            tokens=(char**)realloc(tokens,sizeof(char*)*buf);
            if(!tokens){
                fprintf(stderr,"Memory allocation error\n");
                exit(EXIT_FAILURE);
            }
        }
    }
    tokens[i]=NULL;
    return tokens;
}


int make_cd(char** ar);
int make_exit(char** ar);
char *built_in[]={"cd","exit"};
//built_in={"cd","exit"};
int (*built_func[])(char**)={&make_cd,&make_exit};
//*built_func={&make_cd,&make_exit};

int make_cd(char **args){
    if(args[1]==NULL){
        //fprintf(stderr,"No arhument for cd\n");
        chdir("/home");
    }
    if(strcmp(args[1],"~")==0)
    {
        chdir("/home");
    }
    else{
        if(chdir(args[1])!=0){
            perror("make_cd");
            //printf(stderr,"unable to change directory\n");
        }
    }
    return 1;
}

int make_exit(char **args){
    return 0;
}

int executecmd(char** args){
    if(args[0]==NULL)
        return 1;
    for(int i=0;i<2;i++){
        if (strcmp(args[0],built_in[i])==0){
            return(*built_func[i])(args);
        }
    }
     if(strcmp(args[0],"$$")==0){
        pid_t pid = getpid();
        printf("pid: %lu\n", pid);
        return 1;
    }
    //string strw;
   // strw=args[0];
    if(strcmp(args[0],"alias")==0)
    {
         string s1;
         s1=args[1];
         string s2(args[3]);

        //string s=args[1];
        //string s2=args[3];
        ump[args[1]]=args[3];
       //ump.insert(make_pair("a","b"));
        //printf("hello\n");
        //cout<<ump[args[1]]<<endl;
        return 1;
    }
    string s3(args[0]);
    itr=ump.find(s3);
    if(itr!=ump.end()){
        cout<<args[0]<<endl;
        string s4(itr->second);
        cout<<itr->second<<endl;
      //  char ** tokens=(char **)malloc(sizeof(char *)*256);
        //args[0]=itr->second;
        //char *token=
        //string str = "string";
char *token = new char[s4.length() + 1];
strcpy(token, s4.c_str());
char *tokens[]={token,NULL}; 
        execvp(args[0],args); 

// do stuff
       // args[0]=itr->second;
        //args[1]=NULL;
        //cout<<args[0]<<endl;
    
        pid_t pid;
    pid=fork();
    if(pid==0){
        exit(execvp(tokens[0],tokens));
        //if(execvp(args[0],args)==-1){
          //  fprintf(stderr,"Unable to execute args[0]\n");
            //    exit(EXIT_FAILURE);
        }
    else if(pid<0){
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
    }
    else
    wait(NULL);
    delete [] token;
    return 1;
    } //return 1;
    
    int size_a=0;
    while(args[size_a]!=NULL){
        size_a++;
    }
    //cout<<size_a<<endl;
    int pips=0,redir=0,redap=0;
    for(int i=0;i<size_a;i++){
        if (strcmp(args[i],"|")==0)
            pips++;  
        if(strcmp(args[i],">")==0)
            redir++;
        if(strcmp(args[i],">>")==0)
            redap++;

    }
    int pip=pips+2;
     if(pips>0){

        //char **cmds[pips+1];
        char **cmds[pip];
        for(int i=0;i<pip-1;i++){
            cmds[i]=new char*[30];
        }


        int c1=0,j=0;
        for(int i=0;i<size_a;i++)
        {
           if(strcmp(args[i],"|")!=0){
            cmds[c1][j++]=args[i];
           }
           else{
            cmds[c1][j]=NULL;
            c1++;
            j=0;
           }

        }
        cmds[pip-1]=NULL;
        //cout<<cmds[1][0]<<" "<<cmds[1][4]<<endl;
        pipeline(cmds,pip-2);

    }

    else if(redir>0){
         char **cmds[3];
        for(int i=0;i<2;i++){
            cmds[i]=new char*[30];
        }
        int c1=0,j=0;
        for(int i=0;i<size_a;i++)
        {
            // if(c1==2){
            //     fprintf(stderr,"cant execute more than one redirection\n");
            //    exit(EXIT_FAILURE);

            // }
           if(strcmp(args[i],">")!=0){
            cmds[c1][j++]=args[i];
           }
           else{
            cmds[c1][j]=NULL;
            c1++;
            j=0;
           }
        }
        cmds[2]=NULL;
        redirf(cmds,0,0);
        
         
        // return 1;
     }

     else if(redap>0){
         char **cmds[3];
        for(int i=0;i<2;i++){
            cmds[i]=new char*[30];
        }
        int c1=0,j=0;
        for(int i=0;i<size_a;i++)
        {
            // if(c1==2){
            //     fprintf(stderr,"cant execute more than one redirection\n");
        
    //    exit(EXIT_FAILURE);

            // }
           if(strcmp(args[i],">>")!=0){
            cmds[c1][j++]=args[i];
           }
           else{
            cmds[c1][j]=NULL;
            c1++;
            j=0;
           }
        }
        cmds[2]=NULL;
        redapf(cmds,0,0);
       

         
        // return 1;
     }


    else
    {
    pid_t pid;
    pid=fork();
    if(pid==0){
        exit(execvp(args[0],args));
        //if(execvp(args[0],args)==-1){
          //  fprintf(stderr,"Unable to execute args[0]\n");
            //    exit(EXIT_FAILURE);
        }
    else if(pid<0){
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
    }
    else
    wait(NULL);
    return 1;
    }
    return 1;
    
}

void pipeline(char ***cmd,int pipsl)
{
    int fd[2];
    int flag_for_input=0;
    pid_t pid;
    int fdd = 0;   
    int c=0;   
    int k=0;
    int redirflag=0;
    int redapflag=0;
    char ***cmd1;
    char ***cmd2;
    char ***cmd3;
    cmd1=cmd; 
    cmd2=cmd; 
    cmd3=cmd;     
    while((cmd1)[pipsl][k]!=NULL){
        if(strcmp(cmd1[pipsl][k],">")==0)
            redirflag=1;
        if(strcmp(cmd1[pipsl][k],">>")==0)
            redapflag=1;
        //cout<<(cmd1)[pipsl][k]<<endl;
        k++;


    }
    //cout<<k<<endl;
    //cout<<redirflag<<endl;


    while(*cmd1!=NULL){
        //cout<<(*cmd1)<<endl;
        c++;
        cmd1++;
    }
   // cout<<c<<endl;
    if(redirflag==0 && redapflag==0){
    while (*cmd != NULL)
    {
        pipe(fd);               
        if ((pid = fork()) == -1) {
            perror("fork");
            exit(1);
        }
        else if (pid == 0) {
            dup2(fdd, 0);
            if (*(cmd + 1) != NULL) {
                dup2(fd[1], 1);
            }
            close(fd[0]);
            close(fd[1]);
            execvp((*cmd)[0], *cmd);
            exit(1);
        }
        else {
            wait(NULL);        
            close(fd[1]);
            fdd = fd[0];
            cmd++;
        }
    }
    }
    else if (redirflag){
    for(int l=0;l<pipsl;l++) 
    {
        pipe(fd);               
        if ((pid = fork()) == -1) {
            perror("fork");
            exit(1);
        }
        else if (pid == 0) {
            dup2(fdd, 0);
            if (*(cmd + 1) != NULL) {
                dup2(fd[1], 1);
            }
            close(fd[0]);
            close(fd[1]);
            execvp((*cmd)[0], *cmd);
            exit(1);
        }
        else {
            wait(NULL);        
            close(fd[1]);
            fdd = fd[0];
            cmd++;
        }
    
    }
    char **cmds[3];
        for(int i=0;i<2;i++){
            cmds[i]=new char*[30];
        }
         int size_a=0;
       //  cout<<(cmd)[pipsl][size_a]<<endl;
    while(cmd2[pipsl][size_a]!=NULL){
        //cout<<(cmd2)[pipsl][size_a]<<endl;
         size_a++;
    }
    
   // cout<<(cmd3)[pipsl][0]<<endl;

        int c1=0,j=0;
        for(int i=0;i<size_a;i++)
        {
            // if(c1==2){
            //     fprintf(stderr,"cant execute more than one redirection\n");
            //    exit(EXIT_FAILURE);

            // }
           if(strcmp(cmd3[pipsl][i],">")!=0){
          //  cmds[c1][j++]=cmd3[pipsl][i];
           }
           else{
            cmds[c1][j]=NULL;
            c1++;
            j=0;
           }
        }
        cmds[2]=NULL;
        flag_for_input=1;
        redirf(cmds,fdd,redirflag);

    }
    else if(redapflag){
    for(int l=0;l<pipsl;l++) 
    {
        pipe(fd);               
        if ((pid = fork()) == -1) {
            perror("fork");
            exit(1);
        }
        else if (pid == 0) {
            dup2(fdd, 0);
            if (*(cmd + 1) != NULL) {
                dup2(fd[1], 1);
            }
            close(fd[0]);
            close(fd[1]);
            execvp((*cmd)[0], *cmd);
            exit(1);
        }
        else {
            wait(NULL);        
            close(fd[1]);
            fdd = fd[0];
            cmd++;
        }
    
    }
    char **cmds[3];
        for(int i=0;i<2;i++){
            cmds[i]=new char*[30];
        }
         int size_a=0;
       //  cout<<(cmd)[pipsl][size_a]<<endl;
    while(cmd2[pipsl][size_a]!=NULL){
        //cout<<(cmd2)[pipsl][size_a]<<endl;
         size_a++;
    }
    
   // cout<<(cmd3)[pipsl][0]<<endl;

        int c1=0,j=0;
        for(int i=0;i<size_a;i++)
        {
            // if(c1==2){
            //     fprintf(stderr,"cant execute more than one redirection\n");
            //    exit(EXIT_FAILURE);

            // }
           if(strcmp(cmd3[pipsl][i],">>")!=0){
            cmds[c1][j++]=cmd3[pipsl][i];
           }
           else{
            cmds[c1][j]=NULL;
            c1++;
            j=0;
           }
        }
        cmds[2]=NULL;
        flag_for_input=1;
        redapf(cmds,fdd,redapflag);

    }
}

void redirf(char ***cmds,int fdd,int flag_for_input){
    pid_t pid,pid2;
       // cout<<*(cmds[1])<<endl;
        
        
        pid=fork();
        //close(1);
        if(flag_for_input){
            if(pid==0){
            dup2(fdd,0);
            int fd1=open(*(cmds[1]),O_WRONLY | O_CREAT | O_TRUNC, 0644);
        dup2(fd1,STDOUT_FILENO);
        close(fd1);
            execvp(cmds[0][0],cmds[0]);
            //close(fd1);
            //signal(SIGINT,SIG_DFL);
            //fflush(stdout);
            exit(1);
        }
        //close(fd1);
        else if(pid<0)
        {
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
        }
         else{
            wait(NULL);

        }
    }
        else{


        if(pid==0){
            int fd1=open(*(cmds[1]),O_WRONLY | O_CREAT | O_TRUNC, 0644);
        dup2(fd1,STDOUT_FILENO);
        close(fd1);
            execvp(cmds[0][0],cmds[0]);
            //close(fd1);
            //signal(SIGINT,SIG_DFL);
            //fflush(stdout);
            exit(1);
        }
        //close(fd1);
        else if(pid<0)
        {
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
        }
         else{
            wait(NULL);
            //close(fd1);
            //return 1;
         }
        }

}

void redapf(char ***cmds,int fdd,int flag_for_input){
            pid_t pid,pid2;
        //cout<<*(cmds[1])<<endl;
        
        
        pid=fork();
        //close(1);
         if(flag_for_input){
            if(pid==0){
            dup2(fdd,0);
            int fd1=open(*(cmds[1]),O_APPEND | O_CREAT |O_WRONLY, 0644);
        dup2(fd1,STDOUT_FILENO);
        close(fd1);
            execvp(cmds[0][0],cmds[0]);
            //close(fd1);
            //signal(SIGINT,SIG_DFL);
            //fflush(stdout);
            exit(1);
        }
        //close(fd1);
        else if(pid<0)
        {
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
        }
         else{
            wait(NULL);

        }
    }

        else{
        if(pid==0){
            int fd1=open(*(cmds[1]),O_APPEND | O_CREAT |O_WRONLY,0644);
        dup2(fd1,STDOUT_FILENO);
        
        close(fd1);
            execvp(cmds[0][0],cmds[0]);
            //close(fd1);
            //signal(SIGINT,SIG_DFL);
            //fflush(stdout);
            exit(1);
        }
        
      //close(fd1);
        else if(pid<0)
        {
        fprintf(stderr,"Unable to fork\n");
                exit(EXIT_FAILURE);
        }
         else{
            wait(NULL);
            //close(fd1);
            
         }
     }
}


